<?php
$title         = esc_html__( 'Forms', 'forminator' );
$create_dialog = 'custom_forms';
$import_dialog = 'import_form';
$hash          = '#forms';

require_once forminator_plugin_dir() . 'admin/views/common/list/header.php';
