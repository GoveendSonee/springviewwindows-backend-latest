<?php
// archive-books.php

get_header();
?>

Offers Archive

<?php
get_footer();