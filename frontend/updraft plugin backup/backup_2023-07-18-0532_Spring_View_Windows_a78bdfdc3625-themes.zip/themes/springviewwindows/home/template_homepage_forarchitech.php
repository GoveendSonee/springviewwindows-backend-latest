<?php

/**
 * Template Name:  Homepage 3rd Card For Architects
 */

get_header();
?>

<!-- For Architects  -->
<section id="architechts">
    <div class="container">
        <div class="tilte">
            This content is password protected. To view it please enter your password below:
        </div>
        <div class="login_form">
            <p class="head">Password:</p>
            <input type="text">
            <button>Enter</button>
        </div>
    </div>
</section>
<!-- End Architects  -->

<?php get_footer(); ?>





