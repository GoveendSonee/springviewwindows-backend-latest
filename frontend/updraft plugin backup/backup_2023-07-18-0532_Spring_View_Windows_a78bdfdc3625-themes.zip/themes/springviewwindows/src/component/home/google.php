    <!-- Google Reviews  -->
    <section id="google">
      <div class="container">
          <div class="heading_main">
            <h1><?php the_field( 'google_revews_title' ); ?></h1>
          </div>
       <?php echo do_shortcode( ' [trustindex no-registration=google]' ); ?>
      
      </div>
    </section>
    <!-- End Google Reviews  -->