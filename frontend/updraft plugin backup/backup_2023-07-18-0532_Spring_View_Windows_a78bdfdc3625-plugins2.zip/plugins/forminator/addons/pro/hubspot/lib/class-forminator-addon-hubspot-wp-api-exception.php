<?php

/**
 * Class Forminator_Addon_Hubspot_Wp_Api_Exception
 * Exception holder for HubSpot wp api
 *
 * @since 1.0 HubSpot Addon
 */
class Forminator_Addon_Hubspot_Wp_Api_Exception extends Forminator_Addon_Hubspot_Exception {
}
